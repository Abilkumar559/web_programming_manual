import { useEffect, useMemo, useRef, useState } from 'react';

const STORAGE_KEY = 'notespace-notes-v1';
const starterNotes = [
  { id: 'welcome-note', title: 'Welcome to NoteSpace', content: '<p>Your notes, all in one place.</p><p>Use the toolbar to <b>bold</b>, <i>italicise</i>, or <u>underline</u> text. Your notes are saved in this browser automatically.</p>', updatedAt: new Date().toISOString() }
];

function readNotes() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : starterNotes;
  } catch {
    return starterNotes;
  }
}

export default function App() {
  const [notes, setNotes] = useState(readNotes);
  const [activeId, setActiveId] = useState(() => readNotes()[0]?.id ?? null);
  const [query, setQuery] = useState('');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [savedLabel, setSavedLabel] = useState('All changes saved');
  const editorRef = useRef(null);
  const activeNote = notes.find(note => note.id === activeId) ?? null;

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    setTitle(activeNote?.title ?? '');
    setContent(activeNote?.content ?? '');
    if (editorRef.current) editorRef.current.innerHTML = activeNote?.content ?? '';
  }, [activeId]);

  const visibleNotes = useMemo(() => notes
    .filter(note => `${note.title} ${note.content.replace(/<[^>]*>/g, ' ')}`.toLowerCase().includes(query.toLowerCase()))
    .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)), [notes, query]);

  function createNote() {
    const note = { id: crypto.randomUUID(), title: 'Untitled note', content: '<p></p>', updatedAt: new Date().toISOString() };
    setNotes(current => [note, ...current]);
    setActiveId(note.id);
  }

  function saveCurrent() {
    if (!activeId) return;
    const nextContent = editorRef.current?.innerHTML ?? content;
    setContent(nextContent);
    setNotes(current => current.map(note => note.id === activeId
      ? { ...note, title: title.trim() || 'Untitled note', content: nextContent, updatedAt: new Date().toISOString() }
      : note));
    setSavedLabel('Saved just now');
  }

  function deleteCurrent() {
    if (!activeNote) return;
    if (!window.confirm('Delete this note? This cannot be undone.')) return;
    const remaining = notes.filter(note => note.id !== activeId);
    setNotes(remaining);
    setActiveId(remaining[0]?.id ?? null);
  }

  function format(command, value = null) {
    editorRef.current?.focus();
    document.execCommand(command, false, value);
    setContent(editorRef.current?.innerHTML ?? '');
  }

  function handleEditorInput() {
    setContent(editorRef.current?.innerHTML ?? '');
    setSavedLabel('Unsaved changes');
  }

  function handleTitleChange(value) {
    setTitle(value);
    setSavedLabel('Unsaved changes');
  }

  function handleEditorBlur() {
    if (activeId) saveCurrent();
  }

  function preview(text) {
    const plain = text.replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').trim();
    return plain || 'No additional text';
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-icon">N</div><div><strong>NoteSpace</strong><span>Rich text notes</span></div></div>
      <button className="new-note" onClick={createNote}><span>＋</span> New note</button>
      <label className="search-box"><span>⌕</span><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search notes..." /></label>
      <div className="list-heading"><span>YOUR NOTES</span><span>{visibleNotes.length}</span></div>
      <div className="notes-list">
        {visibleNotes.map(note => <button key={note.id} className={`note-item ${note.id === activeId ? 'active' : ''}`} onClick={() => { saveCurrent(); setActiveId(note.id); }}>
          <strong>{note.title || 'Untitled note'}</strong><span>{preview(note.content)}</span><small>{new Date(note.updatedAt).toLocaleDateString()}</small>
        </button>)}
        {visibleNotes.length === 0 && <p className="empty-list">No notes found.</p>}
      </div>
      <div className="sidebar-footer"><span className="storage-dot"/> Saved locally in this browser</div>
    </aside>

    <main className="main-area">
      {activeNote ? <>
        <header className="topbar"><div className="breadcrumb">My notes <span>/</span> Editor</div><div className="top-actions"><span className="save-status">● {savedLabel}</span><button className="delete-btn" onClick={deleteCurrent}>Delete note</button><button className="save-btn" onClick={saveCurrent}>Save note</button></div></header>
        <section className="editor-wrap">
          <input className="title-input" value={title} onChange={e => handleTitleChange(e.target.value)} placeholder="Note title" />
          <div className="editor-meta">Last edited {new Date(activeNote.updatedAt).toLocaleString()}</div>
          <div className="toolbar" aria-label="Text formatting toolbar">
            <button title="Bold" onMouseDown={e => e.preventDefault()} onClick={() => format('bold')}><b>B</b></button>
            <button title="Italic" onMouseDown={e => e.preventDefault()} onClick={() => format('italic')}><i>I</i></button>
            <button title="Underline" onMouseDown={e => e.preventDefault()} onClick={() => format('underline')}><u>U</u></button>
            <span className="toolbar-divider"/>
            <button title="Heading 1" onMouseDown={e => e.preventDefault()} onClick={() => format('formatBlock', 'h1')}>H1</button>
            <button title="Heading 2" onMouseDown={e => e.preventDefault()} onClick={() => format('formatBlock', 'h2')}>H2</button>
            <span className="toolbar-divider"/>
            <button title="Align left" onMouseDown={e => e.preventDefault()} onClick={() => format('justifyLeft')}>☰</button>
            <button title="Align center" onMouseDown={e => e.preventDefault()} onClick={() => format('justifyCenter')}>≡</button>
            <button title="Bulleted list" onMouseDown={e => e.preventDefault()} onClick={() => format('insertUnorderedList')}>• List</button>
            <button title="Numbered list" onMouseDown={e => e.preventDefault()} onClick={() => format('insertOrderedList')}>1. List</button>
          </div>
          <div ref={editorRef} className="rich-editor" contentEditable suppressContentEditableWarning onInput={handleEditorInput} onBlur={handleEditorBlur} data-placeholder="Start writing your thoughts..." />
          <div className="editor-bottom"><span>Tip: Select text and use the toolbar to format it.</span><span>{preview(content).length} characters approx.</span></div>
        </section>
      </> : <div className="welcome-empty"><div className="empty-icon">✎</div><h2>Your next idea starts here</h2><p>Create a note to capture thoughts, plans, and ideas.</p><button className="save-btn" onClick={createNote}>＋ Create your first note</button></div>}
    </main>
  </div>;
}
