# React Notes Taking App with Rich Text

A frontend mini-project built with ReactJS and browser LocalStorage. It supports creating, viewing, editing, searching, and deleting notes, along with rich-text formatting.

## Features
- Create, edit, and delete notes
- Rich text formatting: bold, italic, underline, headings, alignment, and lists
- Search notes by title or content
- Automatic local persistence using browser LocalStorage
- Responsive layout for desktop and mobile

## Technology
- ReactJS
- JavaScript (ES modules)
- HTML5
- CSS3
- Vite development server
- Browser LocalStorage

## Requirements
- Node.js 18 or later (recommended)
- npm
- A modern web browser

## Run the project
1. Extract the ZIP file.
2. Open the extracted `react-notes-taking-app` folder in Visual Studio Code.
3. Open the terminal in that folder.
4. Install dependencies:
   ```bash
   npm install
   ```
5. Start the development server:
   ```bash
   npm run dev
   ```
6. Open the local address shown in the terminal (usually `http://localhost:5173`).

## Storage
Notes are stored in the browser LocalStorage under the key `notespace-notes-v1`. Data is local to the browser and origin. Clearing browser site data will remove saved notes. This project does not include a backend, login, cloud sync, or multi-device synchronization.

## Important
This is a frontend-only starter implementation. Test it in your environment and adjust the UI or features to match your final project requirements before submission.
